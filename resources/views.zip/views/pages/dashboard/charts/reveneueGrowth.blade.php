  <!-- Revenue Growth -->
  <div class="col-xxl-4 col-md-7">
    <div class="card h-100">
      <div class="card-body d-flex justify-content-between">
        <div class="d-flex flex-column me-xl-7">
          <div class="card-title mb-auto">
            <h5 class="mb-2 text-nowrap">Revenue Growth</h5>
            <p class="mb-0">Weekly Report</p>
          </div>
          <div class="chart-statistics">
            <h3 class="card-title mb-1">$4,673</h3>
            <span class="badge bg-label-success">+15.2%</span>
          </div>
        </div>
        <div id="revenueGrowth"></div>
      </div>
    </div>
  </div>