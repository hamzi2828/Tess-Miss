@extends('master.master')

@section('title', 'index')

@push('css')
@endpush

@section('content')

 @endsection

@push('script')

@endpush