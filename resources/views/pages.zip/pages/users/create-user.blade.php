@extends('master.master')

<style>
    .form-label {
        font-weight: 500;
        color: #6c757d;
    }

    .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
    }

    .btn-danger {
        background-color: #dc3545;
        border-color: #dc3545;
    }

    /* Remove the border-radius for square inputs */
    .form-control,
    .form-select {
        border-radius: 0px !important;
    }

    /* You can adjust the card radius or leave it as it is */
    .card-custom {
        border-radius: 5px;
        background-color: #f8f9fa;
    }
</style>

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <!-- Left Side: User Details -->
        <div class="col-md-2">
        </div>
        <div class="col-md-8">
            <div class="card shadow-lg p-4 card-custom">
                <h4 class="fw-bold text-primary mb-4">Create User</h4>

                <form method="POST" action="{{ route('users.store') }}" enctype="multipart/form-data" onsubmit="return validatePassword()">
                    @csrf
                
                    <!-- Full Name -->
                    <div class="mb-4">
                        <label class="form-label fw-medium text-secondary" for="userFullname">Full Name</label>
                        <input type="text" class="form-control" id="userFullname" name="userFullname" value="{{ old('userFullname') }}" required />
                    </div>
                
                    <!-- Email -->
                    <div class="mb-4">
                        <label class="form-label fw-medium text-secondary" for="userEmail">Email</label>
                        <input type="email" id="userEmail" class="form-control" name="userEmail" value="{{ old('userEmail') }}" required />
                    </div>
                
                    <!-- Phone -->
                    <div class="mb-4">
                        <label class="form-label fw-medium text-secondary" for="userPhone">Phone</label>
                        <input type="tel" id="userPhone" class="form-control" name="userPhone" value="{{ old('userPhone') }}" />
                    </div>
                
                    <!-- Status -->
                    <div class="mb-4">
                        <label class="form-label fw-medium text-secondary" for="userStatus">Status</label>
                        <select id="userStatus" class="form-select" name="userStatus" required>
                            <option value="active" {{ old('userStatus') == 'active' ? 'selected' : '' }}>Active</option>
                            <option value="inactive" {{ old('userStatus') == 'inactive' ? 'selected' : '' }}>Inactive</option>
                        </select>
                    </div>
                
                    <div class="mb-4">
                        <label for="selectDepartment" class="form-label fw-medium text-secondary"> Department </label>
                        <select class="form-select select2" id="selectDepartment" name="department_id" required>
                            <option selected>Select Department</option>
                            @foreach($departments as $department)
                                <option value="{{ $department->id }}">{{ $department->title }}</option>
                            @endforeach
                        </select>
                    </div>
                
          
                
                    <!-- Password -->
                    <div class="mb-4">
                        <label class="form-label fw-medium text-secondary" for="userPassword">Password</label>
                        <input type="password" id="userPassword" class="form-control" name="userPassword" required />
                    </div>
                
                    <!-- Confirm Password -->
                    <div class="mb-4">
                        <label class="form-label fw-medium text-secondary" for="userPasswordConfirmation">Confirm Password</label>
                        <input type="password" id="userPasswordConfirmation" class="form-control" name="userPasswordConfirmation" required />
                    </div>
                
                    <!-- File input -->
                    <div class="mb-4">
                        <label class="form-label fw-medium text-secondary" for="file-input">Upload Profile Picture</label>
                        <div class="input-group">
                            <input type="file" class="form-control" id="file-input" name="userPicture" accept="image/*">
                        </div>
                    </div>
                
                    <!-- Address -->
                    <div class="mb-4">
                        <label class="form-label fw-medium text-secondary" for="userAddress">Address</label>
                        <textarea id="userAddress" class="form-control" name="userAddress" rows="3">{{ old('userAddress') }}</textarea>
                    </div>
                
                    <!-- Submit & Cancel Buttons -->
                    <div class="d-flex justify-content-end">
                        <button type="submit" class="btn btn-primary px-4 me-3">Create</button>
                        <a href="{{ route('users.index') }}" class="btn btn-danger px-4">Cancel</a>
                    </div>
                </form>
                
                <script>
                    // Initialize Select2 on the initial page load for existing selects
                    document.addEventListener('DOMContentLoaded', function() {
                        $('#selectDepartment').select2({
                            placeholder: 'Select Country',
                            allowClear: true
                        });
                    });
            
                    function validatePassword() {
                        const password = document.getElementById('userPassword').value;
                        const confirmPassword = document.getElementById('userPasswordConfirmation').value;
                        const passwordField = document.getElementById('userPassword');
                        const confirmPasswordField = document.getElementById('userPasswordConfirmation');
            
                        // Reset styles
                        passwordField.style.borderColor = '';
                        confirmPasswordField.style.borderColor = '';
            
                        if (password !== confirmPassword) {
                            // Add red border to both fields
                            passwordField.style.borderColor = 'red';
                            confirmPasswordField.style.borderColor = 'red';
                            alert('Passwords do not match.');
                            return false; // Prevent form submission
                        }
                        return true; // Allow form submission
                    }
                </script>
            </div>
        </div>
    </div>
</div>

@endsection
